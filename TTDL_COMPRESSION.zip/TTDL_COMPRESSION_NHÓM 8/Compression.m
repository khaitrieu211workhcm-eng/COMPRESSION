clc; clear; close all;

%% BƯỚC 1: Load file âm thanh với tần số lấy mẫu Fs = 4000
Fs = 4000; % Tần số lấy mẫu mục tiêu
% Đọc file âm thanh gốc
[mSpeech_full, Fs_orig] = audioread('MaleSpeech-16-4-mono-20secs.wav'); 

% Thiết lập vector thời gian từ 0 đến 1.5s
t = 0:1/Fs:1.5; 
% Lấy đoạn tín hiệu tương ứng với 1.5s đầu tiên và chuyển vị thành hàng
mSpeech = mSpeech_full(1:length(t))'; 

%% BƯỚC 2: Lượng tử hóa đều (Uniform Quantization) tín hiệu 'mSpeech'
L = 16; % Số mức lượng tử hóa
V_p = 0.5625; % Điện áp đỉnh của tín hiệu (Peak voltage)

% Công thức tính khoảng bước lượng tử chuẩn: q = Vp/(L-1)
q = V_p / (L - 1); 

% Tìm chỉ số mức (index) bằng cách chia cho q và làm tròn
indices = round(mSpeech / q); 

% Giới hạn chỉ số (Clipping) để tránh lỗi tràn mức (Saturation)
max_index = (L/2) - 1; % Mức cao nhất (với L=16 là mức 7)
min_index = -(L/2);    % Mức thấp nhất (với L=16 là mức -8)
indices(indices > max_index) = max_index;
indices(indices < min_index) = min_index;

% Tín hiệu sau lượng tử hóa đều (giá trị điện áp khôi phục)
s_q2 = indices * q; 

%% BƯỚC 3: Vẽ đồ thị tín hiệu gốc và tín hiệu lượng tử hóa s_q2
figure('Name', 'Project 1: A-Law and mu-Law Companding');
plot(t, mSpeech, 'LineWidth', 1.5); hold on; % Vẽ tín hiệu mẫu
plot(t, s_q2, 'ro', 'MarkerSize', 5, 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r'); % Vẽ các điểm lượng tử hóa đỏ

%% BƯỚC 4: Tính phương sai sai số và SNR cho s_q2 (Phương pháp số)
error_sq2 = mSpeech - s_q2; % Sai số lượng tử (Quantization error)
var_sq2 = mean(error_sq2.^2); % Phương sai sai số lượng tử (nhiễu)
pow_sig = mean(mSpeech.^2); % Công suất trung bình của tín hiệu gốc
snr_sq2 = pow_sig / var_sq2; % Tỷ số S/N (tuyến tính)

%% BƯỚC 5: Nén tín hiệu (Compression) bằng luật mu-law và A-law
mu = 255; % Hằng số mu tiêu chuẩn
A = 87.6; % Hằng số A tiêu chuẩn
x_max = V_p; y_max = V_p; % Giới hạn điện áp nén

% Công thức nén mu-law chuẩn
s_c5_mu = y_max * (log(1 + mu * abs(mSpeech) / x_max) / log(1 + mu)) .* sign(mSpeech); 

% Công thức nén A-law (chia làm 2 trường hợp theo tỉ lệ x/xmax)
s_c5_A = zeros(size(mSpeech));
idx1 = abs(mSpeech)/x_max <= 1/A; % Đoạn tuyến tính
idx2 = abs(mSpeech)/x_max > 1/A;  % Đoạn logarit
s_c5_A(idx1) = y_max * (A * abs(mSpeech(idx1))/x_max) / (1 + log(A)) .* sign(mSpeech(idx1));
s_c5_A(idx2) = y_max * (1 + log(A * abs(mSpeech(idx2))/x_max)) / (1 + log(A)) .* sign(mSpeech(idx2));

%% BƯỚC 6: Lượng tử hóa tín hiệu đã nén (s_q6)
% Tái sử dụng logic làm tròn và giới hạn mức từ Bước 2
idx_mu = round(s_c5_mu / q); 
idx_mu(idx_mu > max_index) = max_index;
idx_mu(idx_mu < min_index) = min_index;
s_q6_mu = idx_mu * q; % Tín hiệu mu-law sau lượng tử hóa

idx_A = round(s_c5_A / q);
idx_A(idx_A > max_index) = max_index;
idx_A(idx_A < min_index) = min_index;
s_q6_A = idx_A * q; % Tín hiệu A-law sau lượng tử hóa

%% BƯỚC 7: Giải nén/Giãn tín hiệu (Expansion) để khôi phục (s_e7)
% Công thức giãn mu-law đảo ngược
term_mu = (abs(s_q6_mu) * log(1 + mu)) / y_max;
s_e7_mu = (x_max / mu) * (exp(term_mu) - 1) .* sign(s_q6_mu); 

% Công thức giãn A-law đảo ngược
s_e7_A = zeros(size(s_q6_A));
threshold = y_max / (1 + log(A)); % Ngưỡng phân chia đoạn tuyến tính/log
idx3 = abs(s_q6_A) <= threshold;
idx4 = abs(s_q6_A) > threshold;
s_e7_A(idx3) = (abs(s_q6_A(idx3)) * (1 + log(A)) * x_max) / (A * y_max) .* sign(s_q6_A(idx3));
s_e7_A(idx4) = (exp(abs(s_q6_A(idx4)) * (1 + log(A)) / y_max - 1) * x_max) / A .* sign(s_q6_A(idx4));

%% BƯỚC 8: Vẽ bổ sung các tín hiệu nén, lượng tử hóa nén và giãn
plot(t, s_c5_mu, '--', 'LineWidth', 0.5); % Đường nén u-law (nét đứt)
plot(t, s_q6_mu, 'b^', 'MarkerSize', 5, 'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b'); % Điểm lượng tử nén
plot(t, s_e7_mu, 'g*', 'MarkerSize', 5, 'MarkerEdgeColor', 'g'); % Tín hiệu sau khi giãn

legend('Sample signal', 'Uniform quantized values', 'Compress signal', ...
       'Compress quantized values', 'Nouniform quantized values', 'Location', 'northeast');
xlim([0.5275 0.59]); 
grid on;

%% BƯỚC 9: Tính toán và so sánh hiệu năng (Variance & SNR)
% Tính cho u-Law
error_mu = mSpeech - s_e7_mu;
var_mu = mean(error_mu.^2);
snr_mu = pow_sig / var_mu;

% Tính cho A-Law
error_A = mSpeech - s_e7_A;
var_A = mean(error_A.^2);
snr_A = pow_sig / var_A;

% In kết quả ra Command Window để so sánh
fprintf('\nKET QUA\n');
fprintf('1. Luong tu hoa deu (Uniform) - B4: SNR = %.4f\n', snr_sq2);
fprintf('2. Companding (u-Law) - B9: SNR = %.4f\n', snr_mu);
fprintf('3. Companding (A-Law) - B9: SNR = %.4f\n', snr_A);